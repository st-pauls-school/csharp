﻿using System;

namespace october
{
    class Numbers
    {
        public static int HighestCommonFactor(int v1, int v2)
        {
            throw new NotImplementedException();
        }

        public static int LowestCommonMultiple(int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}
