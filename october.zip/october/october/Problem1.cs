﻿using System;

namespace october
{
    internal class Problem1
    {
        internal static void ThreeNPlusOne()
        {
            throw new NotImplementedException();
        }
    }
}