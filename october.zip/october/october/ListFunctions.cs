﻿using System;
using System.Collections.Generic;

namespace october
{
    class ListFunctions
    {
        public static double SumTheNumbers(List<string> values)
        {
            // take the list of strings and return the sum of the numbers contained. If the string is not a number it counts as 0. 
            return 0;
        }

        public static bool IsSet<T>(List<T> values)
        {
            // determine if the incoming list is, mathematically, a set, i.e. all the values are distinct and are not repeated 
            throw new NotImplementedException();
        }

        public static bool AreEquivalent(List<int> values1, List<int> values2)
        {
            // two lists are equivalent if they contain the same values but are not actually the same list 
            throw new NotImplementedException();
        }
    }
}
