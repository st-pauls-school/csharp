﻿using System.Collections.Generic;

namespace october
{
    class Median
    {
        public static double GetTheMedianValue(List<int> incoming)
        {
            // this function takes an unsorted list of integers and will return the median value. 
            int returnvalue = 0;


            return returnvalue;
        }
    }
}
